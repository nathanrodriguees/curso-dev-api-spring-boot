package br.edu.senaisp.Aula21_03_04_25;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula21030425Application {

	public static void main(String[] args) {
		SpringApplication.run(Aula21030425Application.class, args);
	}

}
