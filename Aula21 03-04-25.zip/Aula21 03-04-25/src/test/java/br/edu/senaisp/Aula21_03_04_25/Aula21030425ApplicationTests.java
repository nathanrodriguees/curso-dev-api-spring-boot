package br.edu.senaisp.Aula21_03_04_25;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula21030425ApplicationTests {

	@Test
	void contextLoads() {
	}

}
